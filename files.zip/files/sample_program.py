import hashlib, hmac
from os import urandom


def generate_key_stream(key: str, length: int, IV: bytes = bytes()):
    digest = hashlib.sha256(key.encode() + IV).digest()
    stream = bytearray()
    while len(stream) < length:
        digest = hashlib.sha256(digest + key.encode()).digest()
        stream.extend(digest)
    return stream


def permutate(array: bytes, shifts: bytes) -> bytes:
    _len = len(array)
    array = bytearray(array)
    prev = cur = 0
    for _shift in shifts:
        shift = int(_shift)
        cur += shift
        cur %= _len
        array[cur], array[prev] = array[prev], array[cur]
        prev = cur
    return array


def depermutate(array: bytes, shifts: bytes) -> bytes:
    _len = len(array)
    array = bytearray(array)
    prev = cur = 0
    pairs = []
    for _shift in shifts:
        shift = int(_shift)
        cur += shift
        cur %= _len
        pairs.append((prev, cur))
        prev = cur
    for prev, cur in pairs[::-1]:
        array[cur], array[prev] = array[prev], array[cur]
    return array


def encrypt(text: str, key: str) -> bytes:
    size = (int.from_bytes(urandom(1), 'big') % 32) + 32
    text_bytes = text.encode('utf-8') + urandom(size) + bytes((size,))
    IV = urandom(32)
    text_bytes += hashlib.sha256(text_bytes + IV + key.encode()).digest()
    key_stream = generate_key_stream(key, len(text_bytes), IV)
    encrypted_bytes = bytes(a ^ b for a, b in zip(text_bytes, key_stream))
    return permutate(encrypted_bytes, generate_key_stream(key + key[::-1], len(encrypted_bytes) + 32, IV)) + IV


def decrypt(word: bytes, key: str) -> str:
    encrypted_bytes, IV = word[:-32], word[-32:]
    encrypted_bytes = depermutate(encrypted_bytes, generate_key_stream(key + key[::-1], len(encrypted_bytes) + 32, IV))
    key_stream = generate_key_stream(key, len(encrypted_bytes), IV)
    decrypted_bytes = bytes(a ^ b for a, b in zip(encrypted_bytes, key_stream))
    text_bytes, hash_value = decrypted_bytes[:-32], decrypted_bytes[-32:]
    if hmac.compare_digest(hashlib.sha256(text_bytes + IV + key.encode()).digest(), hash_value):
        return text_bytes[:-int(text_bytes[-1])-1].decode('utf-8')
    raise ValueError("incorrect hash")


def main():
    key = "qwerty123"
    print(f"Ключ: {key!r}")
    texts = "Привет, мир!", "Hello World!", "Meaningfull!", "Trust me bro.", "Не надо ж так!?", "В тягость мне.", "!ot evah tuB", "!?от-как еж илИ", "Ну и надо добавить что-то очень длинное."
    for i, text in enumerate(texts):
        print(f"({i+1}) \"{text}\"")
        encrypted = encrypt(text, key)
        print(f"({i+1}) {encrypted.hex()}")
        print(f"({i+1}) \"{decrypt(encrypted, key)}\"")

    originals = "Привет, мир! Конец.", "Привет, я! Конец.", "Привет, всем! Конец.", "Привет, кого не видел! Конец.", "Привет, друзья! Конец."
    for original in originals:
        encrypted = encrypt(original, key)
        print(f"Зашифровано (hex): {encrypted.hex()}")

        decrypted = decrypt(encrypted, key)
        print("Расшифровано:", decrypted)


if __name__ == '__main__':
    main()
